|Theme name | Preview|
| --- | --- |
|**[Afterglow](afterglow.yaml)**:|<img src='previews/afterglow.yaml.svg' width='300'>|
|**[Apple Dark](apple_dark.yaml)**:|<img src='previews/apple_dark.yaml.svg' width='300'>|
|**[Apple Light](apple_light.yaml)**:|<img src='previews/apple_light.yaml.svg' width='300'>|
|**[Arc Dark](arc_dark.yaml)**:|<img src='previews/arc_dark.yaml.svg' width='300'>|
|**[Argonaut](argonaut.yaml)**:|<img src='previews/argonaut.yaml.svg' width='300'>|
|**[Avirage](avirage.yaml)**:|<img src='previews/avirage.yaml.svg' width='300'>|
|**[Ayu Dark](ayu_dark.yaml)**:|<img src='previews/ayu_dark.yaml.svg' width='300'>|
|**[Ayu Light](ayu_light.yaml)**:|<img src='previews/ayu_light.yaml.svg' width='300'>|
|**[Ayu Mirage](ayu_mirage.yaml)**:|<img src='previews/ayu_mirage.yaml.svg' width='300'>|
|**[Azuki](azuki.yaml)**:|<img src='previews/azuki.yaml.svg' width='300'>|
|**[Bilibili Dark](bilibili_dark.yaml)**:|<img src='previews/bilibili_dark.yaml.svg' width='300'>|
|**[Blood Moon](blood_moon.yaml)**:|<img src='previews/blood_moon.yaml.svg' width='300'>|
|**[Blue Monday](blue_monday.yaml)**:|<img src='previews/blue_monday.yaml.svg' width='300'>|
|**[Breeze](breeze.yaml)**:|<img src='previews/breeze.yaml.svg' width='300'>|
|**[Campbell](campbell.yaml)**:|<img src='previews/campbell.yaml.svg' width='300'>|
|**[Catppuccin](catppuccin.yaml)**:|<img src='previews/catppuccin.yaml.svg' width='300'>|
|**[Challenger Deep](challenger_deep.yaml)**:|<img src='previews/challenger_deep.yaml.svg' width='300'>|
|**[Cherry](cherry.yaml)**:|<img src='previews/cherry.yaml.svg' width='300'>|
|**[Classic Vivid](classic_vivid.yaml)**:|<img src='previews/classic_vivid.yaml.svg' width='300'>|
|**[Cobalt 2](cobalt_2.yaml)**:|<img src='previews/cobalt_2.yaml.svg' width='300'>|
|**[Cobalt Next](cobalt_next.yaml)**:|<img src='previews/cobalt_next.yaml.svg' width='300'>|
|**[Cyberpunk-2077](cyberpunk-2077.yaml)**:|<img src='previews/cyberpunk-2077.yaml.svg' width='300'>|
|**[Cyberpunk-neon](cyberpunk-neon.yaml)**:|<img src='previews/cyberpunk-neon.yaml.svg' width='300'>|
|**[Cyberpunk-night City](cyberpunk-night_city.yaml)**:|<img src='previews/cyberpunk-night_city.yaml.svg' width='300'>|
|**[Cyberpunk-v](cyberpunk-v.yaml)**:|<img src='previews/cyberpunk-v.yaml.svg' width='300'>|
|**[Daobeam](daobeam.yaml)**:|<img src='previews/daobeam.yaml.svg' width='300'>|
|**[Darcula](darcula.yaml)**:|<img src='previews/darcula.yaml.svg' width='300'>|
|**[Dark-pinkish](dark-pinkish.yaml)**:|<img src='previews/dark-pinkish.yaml.svg' width='300'>|
|**[Dark Pastels](dark_pastels.yaml)**:|<img src='previews/dark_pastels.yaml.svg' width='300'>|
|**[Deep Ocean](deep_ocean.yaml)**:|<img src='previews/deep_ocean.yaml.svg' width='300'>|
|**[Default Dark](default_dark.yaml)**:|<img src='previews/default_dark.yaml.svg' width='300'>|
|**[Dracula](dracula.yaml)**:|<img src='previews/dracula.yaml.svg' width='300'>|
|**[Edgerunners-david](edgerunners-david.yaml)**:|<img src='previews/edgerunners-david.yaml.svg' width='300'>|
|**[Edgerunners-lucy And David Jump](edgerunners-lucy_and_david_jump.yaml)**:|<img src='previews/edgerunners-lucy_and_david_jump.yaml.svg' width='300'>|
|**[Everforest Hard](everforest_hard.yaml)**:|<img src='previews/everforest_hard.yaml.svg' width='300'>|
|**[Everforest Light](everforest_light.yaml)**:|<img src='previews/everforest_light.yaml.svg' width='300'>|
|**[Fairyfloss](fairyfloss.yaml)**:|<img src='previews/fairyfloss.yaml.svg' width='300'>|
|**[Faithful Argonaut](faithful_argonaut.yaml)**:|<img src='previews/faithful_argonaut.yaml.svg' width='300'>|
|**[Falcon](falcon.yaml)**:|<img src='previews/falcon.yaml.svg' width='300'>|
|**[Flat Remix](flat_remix.yaml)**:|<img src='previews/flat_remix.yaml.svg' width='300'>|
|**[Github Dark](github_dark.yaml)**:|<img src='previews/github_dark.yaml.svg' width='300'>|
|**[Github Dark Dimmed](github_dark_dimmed.yaml)**:|<img src='previews/github_dark_dimmed.yaml.svg' width='300'>|
|**[Github Light](github_light.yaml)**:|<img src='previews/github_light.yaml.svg' width='300'>|
|**[Gotham](gotham.yaml)**:|<img src='previews/gotham.yaml.svg' width='300'>|
|**[Green Geeko](green_geeko.yaml)**:|<img src='previews/green_geeko.yaml.svg' width='300'>|
|**[Gruvbox Dark](gruvbox_dark.yaml)**:|<img src='previews/gruvbox_dark.yaml.svg' width='300'>|
|**[Gruvbox Light](gruvbox_light.yaml)**:|<img src='previews/gruvbox_light.yaml.svg' width='300'>|
|**[Gruvbox Material](gruvbox_material.yaml)**:|<img src='previews/gruvbox_material.yaml.svg' width='300'>|
|**[Hackthebox](hackthebox.yaml)**:|<img src='previews/hackthebox.yaml.svg' width='300'>|
|**[Halcyon](halcyon.yaml)**:|<img src='previews/halcyon.yaml.svg' width='300'>|
|**[High Contrast](high_contrast.yaml)**:|<img src='previews/high_contrast.yaml.svg' width='300'>|
|**[Horizon Dark](horizon_dark.yaml)**:|<img src='previews/horizon_dark.yaml.svg' width='300'>|
|**[Hyper](hyper.yaml)**:|<img src='previews/hyper.yaml.svg' width='300'>|
|**[Iceberg](iceberg.yaml)**:|<img src='previews/iceberg.yaml.svg' width='300'>|
|**[Iterm](iterm.yaml)**:|<img src='previews/iterm.yaml.svg' width='300'>|
|**[Jellybeans](jellybeans.yaml)**:|<img src='previews/jellybeans.yaml.svg' width='300'>|
|**[Kanagawa](kanagawa.yaml)**:|<img src='previews/kanagawa.yaml.svg' width='300'>|
|**[Konsole Linux](konsole_linux.yaml)**:|<img src='previews/konsole_linux.yaml.svg' width='300'>|
|**[Laser](laser.yaml)**:|<img src='previews/laser.yaml.svg' width='300'>|
|**[Light-pinkish](light-pinkish.yaml)**:|<img src='previews/light-pinkish.yaml.svg' width='300'>|
|**[Low Contrast](low_contrast.yaml)**:|<img src='previews/low_contrast.yaml.svg' width='300'>|
|**[Lucario](lucario.yaml)**:|<img src='previews/lucario.yaml.svg' width='300'>|
|**[Material Theme](material_theme.yaml)**:|<img src='previews/material_theme.yaml.svg' width='300'>|
|**[Material Theme Mod](material_theme_mod.yaml)**:|<img src='previews/material_theme_mod.yaml.svg' width='300'>|
|**[Matrix Dracula](matrix_dracula.yaml)**:|<img src='previews/matrix_dracula.yaml.svg' width='300'>|
|**[Matrix Dracula Switcheroo](matrix_dracula_switcheroo.yaml)**:|<img src='previews/matrix_dracula_switcheroo.yaml.svg' width='300'>|
|**[Monokai Pro](monokai_pro.yaml)**:|<img src='previews/monokai_pro.yaml.svg' width='300'>|
|**[Monokai Pro Classic](monokai_pro_classic.yaml)**:|<img src='previews/monokai_pro_classic.yaml.svg' width='300'>|
|**[Monokai Pro Machine](monokai_pro_machine.yaml)**:|<img src='previews/monokai_pro_machine.yaml.svg' width='300'>|
|**[Monokai Pro Octagon](monokai_pro_octagon.yml)**:|<img src='previews/monokai_pro_octagon.yml.svg' width='300'>|
|**[Monokai Pro Ristretto](monokai_pro_ristretto.yml)**:|<img src='previews/monokai_pro_ristretto.yml.svg' width='300'>|
|**[Monokai Pro Spectrum](monokai_pro_spectrum.yml)**:|<img src='previews/monokai_pro_spectrum.yml.svg' width='300'>|
|**[Night Owl](night_owl.yaml)**:|<img src='previews/night_owl.yaml.svg' width='300'>|
|**[Nightfly](nightfly.yaml)**:|<img src='previews/nightfly.yaml.svg' width='300'>|
|**[Nord](nord.yaml)**:|<img src='previews/nord.yaml.svg' width='300'>|
|**[Oceanic Next](oceanic_next.yaml)**:|<img src='previews/oceanic_next.yaml.svg' width='300'>|
|**[Omni](omni.yaml)**:|<img src='previews/omni.yaml.svg' width='300'>|
|**[One Dark](one_dark.yaml)**:|<img src='previews/one_dark.yaml.svg' width='300'>|
|**[One Monokai](one_monokai.yaml)**:|<img src='previews/one_monokai.yaml.svg' width='300'>|
|**[Outrun](outrun.yaml)**:|<img src='previews/outrun.yaml.svg' width='300'>|
|**[Palenight](palenight.yaml)**:|<img src='previews/palenight.yaml.svg' width='300'>|
|**[Panda Syntax](panda_syntax.yaml)**:|<img src='previews/panda_syntax.yaml.svg' width='300'>|
|**[Papercolor Light](papercolor_light.yaml)**:|<img src='previews/papercolor_light.yaml.svg' width='300'>|
|**[Pencil Dark](pencil_dark.yaml)**:|<img src='previews/pencil_dark.yaml.svg' width='300'>|
|**[Pencil Light](pencil_light.yaml)**:|<img src='previews/pencil_light.yaml.svg' width='300'>|
|**[Penumbra Dark](penumbra_dark.yaml)**:|<img src='previews/penumbra_dark.yaml.svg' width='300'>|
|**[Penumbra Light](penumbra_light.yaml)**:|<img src='previews/penumbra_light.yaml.svg' width='300'>|
|**[Plastic](plastic.yaml)**:|<img src='previews/plastic.yaml.svg' width='300'>|
|**[Poimandres](poimandres.yaml)**:|<img src='previews/poimandres.yaml.svg' width='300'>|
|**[Poimandres Alt](poimandres_alt.yaml)**:|<img src='previews/poimandres_alt.yaml.svg' width='300'>|
|**[Popos Dark](popos_dark.yaml)**:|<img src='previews/popos_dark.yaml.svg' width='300'>|
|**[Popos Light](popos_light.yaml)**:|<img src='previews/popos_light.yaml.svg' width='300'>|
|**[Remedy Dark](remedy_dark.yaml)**:|<img src='previews/remedy_dark.yaml.svg' width='300'>|
|**[Seashells](seashells.yaml)**:|<img src='previews/seashells.yaml.svg' width='300'>|
|**[Shades Of Purple](shades_of_purple.yaml)**:|<img src='previews/shades_of_purple.yaml.svg' width='300'>|
|**[Shades Of Purple Super Dark](shades_of_purple_super_dark.yaml)**:|<img src='previews/shades_of_purple_super_dark.yaml.svg' width='300'>|
|**[Simply Dark](simply_dark.yaml)**:|<img src='previews/simply_dark.yaml.svg' width='300'>|
|**[Snazzy](snazzy.yaml)**:|<img src='previews/snazzy.yaml.svg' width='300'>|
|**[Snazzy Blue](snazzy_blue.yaml)**:|<img src='previews/snazzy_blue.yaml.svg' width='300'>|
|**[Snazzy Green](snazzy_green.yaml)**:|<img src='previews/snazzy_green.yaml.svg' width='300'>|
|**[Snazzy Red](snazzy_red.yaml)**:|<img src='previews/snazzy_red.yaml.svg' width='300'>|
|**[Soft One Dark](soft_one_dark.yaml)**:|<img src='previews/soft_one_dark.yaml.svg' width='300'>|
|**[Solarized Dark](solarized_dark.yaml)**:|<img src='previews/solarized_dark.yaml.svg' width='300'>|
|**[Solarized Light](solarized_light.yaml)**:|<img src='previews/solarized_light.yaml.svg' width='300'>|
|**[Spaceduck](spaceduck.yaml)**:|<img src='previews/spaceduck.yaml.svg' width='300'>|
|**[Synthwave 84](synthwave_84.yaml)**:|<img src='previews/synthwave_84.yaml.svg' width='300'>|
|**[Taerminal](taerminal.yaml)**:|<img src='previews/taerminal.yaml.svg' width='300'>|
|**[Tango Dark](tango_dark.yaml)**:|<img src='previews/tango_dark.yaml.svg' width='300'>|
|**[Tender](tender.yaml)**:|<img src='previews/tender.yaml.svg' width='300'>|
|**[Terminal App](terminal_app.yaml)**:|<img src='previews/terminal_app.yaml.svg' width='300'>|
|**[Thelovelace](thelovelace.yaml)**:|<img src='previews/thelovelace.yaml.svg' width='300'>|
|**[Tokyo Night](tokyo_night.yaml)**:|<img src='previews/tokyo_night.yaml.svg' width='300'>|
|**[Tokyo Night Storm](tokyo_night_storm.yaml)**:|<img src='previews/tokyo_night_storm.yaml.svg' width='300'>|
|**[Tomorrow Night](tomorrow_night.yaml)**:|<img src='previews/tomorrow_night.yaml.svg' width='300'>|
|**[Tomorrow Night Bright](tomorrow_night_bright.yaml)**:|<img src='previews/tomorrow_night_bright.yaml.svg' width='300'>|
|**[Vitesse Black](vitesse_black.yaml)**:|<img src='previews/vitesse_black.yaml.svg' width='300'>|
|**[Vitesse Dark](vitesse_dark.yaml)**:|<img src='previews/vitesse_dark.yaml.svg' width='300'>|
|**[Vitesse Dark Soft](vitesse_dark_soft.yaml)**:|<img src='previews/vitesse_dark_soft.yaml.svg' width='300'>|
|**[Vitesse Light](vitesse_light.yaml)**:|<img src='previews/vitesse_light.yaml.svg' width='300'>|
|**[Vitesse Light Soft](vitesse_light_soft.yaml)**:|<img src='previews/vitesse_light_soft.yaml.svg' width='300'>|
|**[Vscode Default Dark Material](vscode_default_dark_material.yml)**:|<img src='previews/vscode_default_dark_material.yml.svg' width='300'>|
|**[Vuesion](vuesion.yaml)**:|<img src='previews/vuesion.yaml.svg' width='300'>|
|**[Wombat](wombat.yaml)**:|<img src='previews/wombat.yaml.svg' width='300'>|
|**[Xterm](xterm.yaml)**:|<img src='previews/xterm.yaml.svg' width='300'>|
|**[Zenbones Dark](zenbones_dark.yaml)**:|<img src='previews/zenbones_dark.yaml.svg' width='300'>|
|**[Zenbones Light](zenbones_light.yaml)**:|<img src='previews/zenbones_light.yaml.svg' width='300'>|